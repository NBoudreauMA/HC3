# HubbCONNECT WOW Theme Pack
Drop-in modern theme for your Agnostic Beta 2 build.

## Use
<link rel='stylesheet' href='assets/css/hubb-wow.css'>
<script src='assets/js/wow.js' defer></script>

© 2025 HubbCONNECT